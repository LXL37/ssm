create definer = root@localhost trigger DELETE_S
    before delete
    on s
    for each row
BEGIN
	DELETE FROM spj WHERE SPJ.SNO ='S2';
END;

