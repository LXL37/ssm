create definer = root@localhost trigger trigger_delete
    before delete
    on s
    for each row
    DELETE FROM spj WHERE spj.SNO=OLD.SNO;

