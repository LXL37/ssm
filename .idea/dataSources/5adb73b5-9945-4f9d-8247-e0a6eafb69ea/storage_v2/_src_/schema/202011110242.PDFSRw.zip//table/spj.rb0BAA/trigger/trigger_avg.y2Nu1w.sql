create definer = root@localhost trigger trigger_avg
    after insert
    on spj
    for each row
    UPDATE s  SET s.AvgQty=(SELECT avg(Qty)  from spj where spj.sno=NEW.SNO)
where s.sno =NEW.SNO;

