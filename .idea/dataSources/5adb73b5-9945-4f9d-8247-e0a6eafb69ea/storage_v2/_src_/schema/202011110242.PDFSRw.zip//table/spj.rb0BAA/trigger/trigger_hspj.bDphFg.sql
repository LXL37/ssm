create definer = root@localhost trigger trigger_hspj
    after update
    on spj
    for each row
    INSERT INTO hspj(SNO,PNO,JNO,QTY,USERNAME,MODIFYDATE) VALUES(OLD.SNO,OLD.PNO,OLD.JNO,OLD.QTY,CURRENT_USER,CURRENT_TIMESTAMP);

