create definer = root@localhost view view_1 as
select `202011110242`.`spj`.`SNO` AS `SNO`, `202011110242`.`spj`.`PNO` AS `PNO`, `202011110242`.`spj`.`QTY` AS `QTY`
from `202011110242`.`spj`
         join `202011110242`.`j`
where ((`202011110242`.`spj`.`JNO` = `202011110242`.`j`.`JNO`) and (`202011110242`.`j`.`JNAME` = '建工集团'));

