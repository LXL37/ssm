create definer = root@localhost view view_2 as
select `202011110242`.`s`.`SNAME` AS `SNAME`,
       `202011110242`.`p`.`PNAME` AS `PNAME`,
       `202011110242`.`j`.`JNAME` AS `JNAME`,
       `202011110242`.`spj`.`QTY` AS `QTY`
from `202011110242`.`s`
         join `202011110242`.`p`
         join `202011110242`.`j`
         join `202011110242`.`spj`
where ((`202011110242`.`spj`.`JNO` = `202011110242`.`j`.`JNO`) and
       (`202011110242`.`spj`.`PNO` = `202011110242`.`p`.`PNO`) and
       (`202011110242`.`spj`.`SNO` = `202011110242`.`s`.`SNO`) and (`202011110242`.`j`.`JNAME` = '建工集团'));

