create
    definer = root@localhost procedure InsertS(IN SSNO varchar(10), IN SSNAME varchar(10), IN SSTATUS int,
                                               IN SCITY varchar(10))
BEGIN
	INSERT INTO s(SNO,SNAME,`STATUS`,CITY) VALUES(SSNO,SSNAME,SSTATUS,SCITY);
	
END;

