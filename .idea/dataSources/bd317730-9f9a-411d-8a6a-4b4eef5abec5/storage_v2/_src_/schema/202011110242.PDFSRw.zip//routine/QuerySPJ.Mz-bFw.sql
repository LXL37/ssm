create
    definer = root@localhost procedure QuerySPJ(IN JJNO varchar(10), OUT 总数量 int)
BEGIN
		SET 总数量=(SELECT SUM(spj.QTY) FROM spj WHERE spj.JNO=JJNO);
END;

