create
    definer = root@localhost procedure proc_insert_J(IN args int)
BEGIN
	DECLARE i INT DEFAULT 0;
-- 	开启事务，不开的话100w条按天算
	start transaction;
	REPEAT
		set i=i+1;
		insert into J values(concat('J',i),CONCAT('项目',i),'济南');	
	  UNTIL i >= args END REPEAT;
	commit;
END;

