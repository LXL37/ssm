create definer = root@localhost trigger DELETE_J
    before delete
    on j
    for each row
BEGIN
	DELETE FROM spj WHERE SPJ.JNO ='J3';
END;

